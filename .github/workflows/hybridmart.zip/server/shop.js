'use strict';
const {q,tx,dec,cfg,audit,mkpw}=require('./db');
const {bad,rid,int,str}=require('./lib');
const {A,PROVIDERS}=require('./payments');
const J=(s,d)=>{try{return JSON.parse(s)}catch{return d}};
const LISTED="p.status='active' AND s.status='approved'";
/* ---- pricing (all money is integer minor units; the browser is never trusted for prices) ---- */
const tiers=p=>J(p.tiers,[]).sort((a,b)=>a.min-b.min);
const unitPrice=(p,n)=>{let u=p.price;if(p.order_type==='bulk')for(const t of tiers(p))if(n>=t.min)u=t.price;return u};
const minQty=p=>p.order_type==='bulk'?Math.max(1,p.moq||1):1;
function quote(items){
 if(!Array.isArray(items)||!items.length||items.length>50)bad('Your cart is empty');
 const c=cfg(),lines=[],seen=new Set();
 for(const it of items){const id=int(it.id,1,1e9),qty=int(it.qty,1,1e7);if(seen.has(id))continue;seen.add(id);
  const p=q.get(`SELECT p.*,s.business FROM products p JOIN sellers s ON s.id=p.seller_id WHERE p.id=? AND ${LISTED}`,id);if(!p)bad('An item in your cart is no longer available');
  if(qty<minQty(p))bad(`Minimum order for “${p.title}” is ${minQty(p)}`);if(p.type==='physical'&&p.stock!=null&&qty>p.stock)bad(`Only ${p.stock} of “${p.title}” left in stock`);
  const unit=unitPrice(p,qty);lines.push({p,qty,unit,total:unit*qty})}
 const by={};for(const l of lines){const g=by[l.p.seller_id]??={sellerId:l.p.seller_id,business:l.p.business,lines:[],subtotal:0,shipping:0};g.lines.push(l);g.subtotal+=l.total;if(l.p.type==='physical')g.shipping+=l.p.ship_fee||0}
 let total=0;const groups=Object.values(by);
 for(const g of groups){g.tax=c.taxOn?Math.round(g.subtotal*c.taxRate/100):0;g.fee=Math.round(g.subtotal*c.commission/100);g.total=g.subtotal+g.shipping+g.tax;g.net=g.subtotal-g.fee+g.shipping;total+=g.total}
 return{groups,total,currency:c.currency,needsAddress:lines.some(l=>l.p.type==='physical')}}
const quoteOut=Q=>({total:Q.total,currency:Q.currency,needsAddress:Q.needsAddress,groups:Q.groups.map(g=>({business:g.business,subtotal:g.subtotal,shipping:g.shipping,tax:g.tax,total:g.total,lines:g.lines.map(l=>({id:l.p.id,title:l.p.title,qty:l.qty,unit:l.unit,total:l.total,type:l.p.type,image:J(l.p.images,[])[0]?'/files/'+J(l.p.images,[])[0]:null,emoji:l.p.emoji,hue:l.p.hue}))}))});
/* ---- checkout ---- */
async function checkout({items,address,methodId,user,base}){
 const Q=quote(items),m=q.get('SELECT * FROM payment_methods WHERE id=? AND enabled=1',int(methodId,1,1e9,0));if(!m)bad('Please choose a payment method');
 if(m.provider==='sandbox'&&process.env.NODE_ENV==='production')bad('Test payments are disabled');
 let addr=null;if(Q.needsAddress){address=address||{};addr={name:str(address.name,100,2),phone:str(address.phone,40,5),line1:str(address.line1,200,3),city:str(address.city,80,2),region:str(address.region,80),country:str(address.country,80,2),notes:str(address.notes,300)}}
 const c=cfg(),pid='PAY-'+rid(5).toUpperCase(),exp=Date.now()+(m.provider==='manual'?72:1)*3600e3;
 tx(()=>{for(const g of Q.groups)for(const l of g.lines)if(l.p.type==='physical'&&l.p.stock!=null&&q.run('UPDATE products SET stock=stock-? WHERE id=? AND stock>=?',l.qty,l.p.id,l.qty).changes===0)bad(`“${l.p.title}” just sold out`);
  q.run('INSERT INTO payments(id,customer_id,method_id,provider,label,amount,currency,status,expires)VALUES(?,?,?,?,?,?,?,?,?)',pid,user.id,m.id,m.provider,m.label,Q.total,c.currency,'pending',exp);
  for(const g of Q.groups){const o=q.run('INSERT INTO orders(payment_id,customer_id,seller_id,status,subtotal,shipping,tax,fee,total,seller_net,address)VALUES(?,?,?,?,?,?,?,?,?,?,?)',pid,user.id,g.sellerId,'Awaiting payment',g.subtotal,g.shipping,g.tax,g.fee,g.total,g.net,addr&&g.lines.some(l=>l.p.type==='physical')?JSON.stringify(addr):null).lastInsertRowid;
   for(const l of g.lines)q.run('INSERT INTO order_items(order_id,product_id,title,type,qty,unit,total,image)VALUES(?,?,?,?,?,?,?,?)',o,l.p.id,l.p.title,l.p.type,l.qty,l.unit,l.total,J(l.p.images,[])[0]||null)}});
 try{const x={c:dec(m.cfg),pay:{id:pid,amount:Q.total,currency:c.currency},user,site:c.siteName,base,ret:`${base}/pay/return/${pid}`,hook:`${base}/api/webhooks/${m.provider}/${m.id}`};
  const r=await A[m.provider].create(x);q.run('UPDATE payments SET provider_ref=? WHERE id=?',r.ref||null,pid);
  return{paymentId:pid,total:Q.total,next:r.redirect?{type:'redirect',url:r.redirect}:{type:'manual',instructions:r.manual}}}
 catch(e){cancelPayment(pid,'failed');audit('system','payment_create_failed',`${pid} ${m.provider}: ${e.message}`);throw e}}
function cancelPayment(pid,status='cancelled'){tx(()=>{const p=q.get('SELECT * FROM payments WHERE id=?',pid);if(!p||!['pending','awaiting_confirmation'].includes(p.status))return;q.run('UPDATE payments SET status=? WHERE id=?',status,pid);
 for(const o of q.all("SELECT id FROM orders WHERE payment_id=? AND status='Awaiting payment'",pid)){q.run("UPDATE orders SET status='Cancelled' WHERE id=?",o.id);for(const i of q.all('SELECT i.* FROM order_items i WHERE order_id=?',o.id))q.run("UPDATE products SET stock=stock+? WHERE id=? AND type='physical' AND stock IS NOT NULL",i.qty,i.product_id)}})}
function markPaid(pid,actor='system'){return tx(()=>{const p=q.get('SELECT * FROM payments WHERE id=?',pid);if(!p)return false;if(p.status==='paid')return true;if(!['pending','awaiting_confirmation'].includes(p.status))return false;
 const now=new Date().toISOString();q.run("UPDATE payments SET status='paid',paid_at=? WHERE id=?",now,pid);
 for(const o of q.all('SELECT * FROM orders WHERE payment_id=?',pid)){const items=q.all('SELECT * FROM order_items WHERE order_id=?',o.id),dig=items.every(i=>i.type==='digital');
  q.run('UPDATE orders SET status=?,completed_at=? WHERE id=?',dig?'Completed':'Processing',dig?now:null,o.id);for(const i of items)q.run('UPDATE products SET sold=sold+? WHERE id=?',i.qty,i.product_id)}
 audit(actor,'payment_paid',`${pid} ${p.label} ${p.amount}`);return true})}
/* Ask the provider (never the browser) what happened, then settle. */
async function settle(pid,qs={}){const p=q.get('SELECT * FROM payments WHERE id=?',pid);if(!p||['paid','cancelled','failed'].includes(p.status))return p?.status;
 const m=q.get('SELECT * FROM payment_methods WHERE id=?',p.method_id);if(!m||!A[p.provider].verify)return p.status;
 try{const s=await A[p.provider].verify({c:dec(m.cfg),pay:p,q:qs});if(s==='paid')markPaid(pid,'provider:'+p.provider);else if(s==='failed')cancelPayment(pid,'failed')}catch(e){audit('system','verify_error',`${pid}: ${e.message}`)}
 return q.get('SELECT status FROM payments WHERE id=?',pid).status}
/* ---- money for sellers/owner ---- */
const LIVE="status NOT IN ('Awaiting payment','Cancelled','Refunded')";
function sellerBalance(id){const hold=cfg().holdHours*3600e3,now=Date.now();let avail=0,pending=0;
 for(const r of q.all(`SELECT seller_net,status,completed_at FROM orders WHERE seller_id=? AND ${LIVE}`,id))(['Completed','Delivered'].includes(r.status)&&r.completed_at&&Date.parse(r.completed_at)+hold<=now)?avail+=r.seller_net:pending+=r.seller_net;
 const paid=q.get('SELECT COALESCE(SUM(amount),0)s FROM payouts WHERE seller_id=?',id).s;return{available:avail-paid,pending,paidOut:paid,total:avail+pending}}
/* ---- housekeeping: expire unpaid checkouts (returns stock), auto-confirm old shipments ---- */
async function sweep(){try{for(const p of q.all("SELECT id FROM payments WHERE status IN('pending','awaiting_confirmation') AND expires<?",Date.now())){if(p.provider!=='manual')await settle(p.id);const s=q.get('SELECT status FROM payments WHERE id=?',p.id).status;if(['pending','awaiting_confirmation'].includes(s))cancelPayment(p.id,'cancelled')}
 const d=cfg().autoCompleteDays,cut=new Date(Date.now()-d*864e5).toISOString();q.run("UPDATE orders SET status='Delivered',completed_at=? WHERE status='Shipped' AND shipped_at<?",new Date().toISOString(),cut)}catch(e){console.error('sweep',e.message)}}
/* ---- demo data (flagged so it can be removed with one click) ---- */
async function seedDemo(){if(q.get("SELECT 1 x FROM users WHERE demo=1"))return false;const pw=await mkpw('demo1234');
 const U=(role,email,name)=>q.run('INSERT INTO users(role,email,name,salt,hash,demo)VALUES(?,?,?,?,?,1)',role,email,name,pw.salt,pw.hash).lastInsertRowid;
 const S=(email,biz,country,addr,st,reg)=>q.run('INSERT INTO sellers(user_id,business,country,address,reg_no,tax_id,status,demo)VALUES(?,?,?,?,?,?,?,1)',U('seller',email,biz),biz,country,addr,reg,'TAX-'+reg,st).lastInsertRowid;
 U('customer','customer@example.com','Demo Customer');const s1=S('seller@example.com','Northwind Wholesale Co.','United States','Long Beach, CA','approved','NW-44821'),s2=S('hello@pixelforge.example','PixelForge Studio','United Kingdom','London','approved','PF-90177');S('kyb@greenleaf.example','GreenLeaf Organics','South Africa','Cape Town','pending','GL-00312');
 const P=(s,t,cat,sub,type,ot,price,moq,tr,stock,emoji,hue,desc,bl,rt,rc,fee=0)=>q.run('INSERT INTO products(seller_id,title,category,sub,type,order_type,price,moq,tiers,stock,emoji,hue,description,bullets,rating,review_count,ship_fee,delivery,demo,sold)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1,?)',s,t,cat,sub,type,ot,Math.round(price*100),moq,JSON.stringify(tr.map(([min,p])=>({min,price:Math.round(p*100)}))),stock,emoji,hue,desc,JSON.stringify(bl),rt,rc,fee*100,type==='digital'?'Instant download':'3–5 business days',rc*3);
 P(s1,'Ceramic Pour-Over Coffee Set','Home & Kitchen','Kitchen','physical','retail',34,1,[],42,'☕',35,'Hand-glazed ceramic dripper, carafe and two cups. Dishwasher safe.',['Hand-glazed stoneware','Fits standard #2 filters','Dishwasher safe','Gift-box packaging'],4.7,96);
 P(s1,'Organic Cotton Tote Bags (Wholesale)','Apparel & Bags','Bags','physical','bulk',2.8,50,[[50,2.8],[200,2.2],[1000,1.6]],5000,'👜',150,'12oz natural cotton totes. Custom print available on 500+. Priced per unit.',['12oz natural cotton','Reinforced handles','Custom print on 500+','Ships within 5 days'],4.8,61,25);
 P(s1,'Wireless Earbuds Pro','Electronics','Audio','physical','retail',59,1,[],25,'🎧',215,'Active noise cancelling, 28h battery, IPX4.',['Active noise cancelling','28-hour battery','IPX4 sweat resistant','Bluetooth 5.3'],4.4,312,4);
 P(s1,'Steel Water Bottles (Wholesale)','Home & Kitchen','Drinkware','physical','bulk',6.5,24,[[24,6.5],[100,5.2],[500,4.1]],3000,'🧴',200,'750ml double-wall vacuum insulated. Cold 24h / hot 12h.',['Double-wall vacuum','Cold 24h, hot 12h','BPA-free lid','Logo engraving available'],4.6,44,15);
 P(s2,'Lightroom Presets — Golden Hour','Digital Products','Design','digital','retail',19,1,[],null,'🌇',345,'40 warm-toned presets for desktop & mobile. Instant download.',['40 presets','Desktop + mobile','Lifetime updates'],4.9,420);
 P(s2,'UI Kit Pro — Figma Components','Digital Products','Design','digital','retail',49,1,[],null,'🧩',265,'600+ responsive components with light/dark tokens.',['600+ components','Light/dark tokens','Auto-layout'],4.7,188);
 P(s2,'Stock Photo Licence — Team Seats','Digital Products','Stock Media','digital','bulk',12,10,[[10,12],[50,9],[250,6]],null,'📷',235,'Commercial licence per seat covering 5,000 photos.',['Commercial licence','5,000 photos','Per-seat pricing'],4.5,73);
 P(s2,'Online Course: Intro to Python','Digital Products','Education','digital','retail',29,1,[],null,'🐍',175,'12 hours of video lessons plus workbook.',['12 hours of video','Workbook included','Certificate'],4.8,905);
 P(s1,'Recycled Mailer Boxes (Wholesale)','Office & Packaging','Packaging','physical','bulk',.85,100,[[100,.85],[500,.65],[2500,.48]],20000,'📦',30,'Kraft corrugated mailers, 10″×8″×3″.',['100% recycled kraft','Self-seal strip','Custom print on 2,500+'],4.6,38,30);
 P(s1,'Soy Candle Trio','Home & Kitchen','Decor','physical','retail',27,1,[],15,'🕯️',10,'Three 6oz hand-poured candles. 40h burn each.',['Natural soy wax','40-hour burn','Cotton wicks'],4.9,130,3);
 audit('system','demo_loaded');return true}
function purgeDemo(){tx(()=>{const dp=q.all('SELECT id FROM products WHERE demo=1').map(r=>r.id);for(const id of dp){q.run('DELETE FROM reviews WHERE product_id=?',id);q.run('DELETE FROM order_items WHERE product_id=?',id)}
 q.run('DELETE FROM orders WHERE seller_id IN(SELECT id FROM sellers WHERE demo=1) OR customer_id IN(SELECT id FROM users WHERE demo=1)');q.run('DELETE FROM products WHERE demo=1');q.run('DELETE FROM seller_docs WHERE seller_id IN(SELECT id FROM sellers WHERE demo=1)');q.run('DELETE FROM sessions WHERE user_id IN(SELECT id FROM users WHERE demo=1)');q.run('DELETE FROM sellers WHERE demo=1');q.run('DELETE FROM users WHERE demo=1')});audit('owner','demo_removed')}
module.exports={J,LISTED,tiers,unitPrice,minQty,quote,quoteOut,checkout,cancelPayment,markPaid,settle,sellerBalance,sweep,seedDemo,purgeDemo,LIVE};
