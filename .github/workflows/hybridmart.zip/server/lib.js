'use strict';
require('./env');
const crypto=require('crypto');
class HttpError extends Error{constructor(s,m){super(m);this.status=s}}
const bad=(m,s=400)=>{throw new HttpError(s,m)};
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const rid=(n=9)=>crypto.randomBytes(n).toString('hex');
function cookies(req){const o={};for(const p of(req.headers.cookie||'').split(';')){const i=p.indexOf('=');if(i>0)o[p.slice(0,i).trim()]=decodeURIComponent(p.slice(i+1).trim())}return o}
function readBody(req,limit){return new Promise((ok,no)=>{const a=[];let n=0;req.on('data',c=>{n+=c.length;if(n>limit){no(new HttpError(413,'Upload too large'));req.destroy()}else a.push(c)});req.on('end',()=>ok(Buffer.concat(a)));req.on('error',no)})}
function multipart(buf,boundary){const b=Buffer.from('--'+boundary),parts=[];let pos=buf.indexOf(b);while(pos>=0){const next=buf.indexOf(b,pos+b.length);if(next<0)break;let s=pos+b.length;if(buf[s]===13&&buf[s+1]===10)s+=2;const he=buf.indexOf('\r\n\r\n',s);if(he>=0&&he<next){const head=buf.subarray(s,he).toString('utf8');parts.push({name:/name="([^"]*)"/i.exec(head)?.[1],filename:/filename="([^"]*)"/i.exec(head)?.[1],type:/content-type:\s*([^\r\n]+)/i.exec(head)?.[1],data:buf.subarray(he+4,next-2)})}pos=next}return parts}
/* identify real file type from magic bytes — never trust the browser's claim */
function sniff(b){if(b.length<12)return null;const h=b.subarray(0,12);
 if(h[0]===0xff&&h[1]===0xd8&&h[2]===0xff)return{mime:'image/jpeg',img:1};if(h.subarray(0,8).equals(Buffer.from([0x89,0x50,0x4e,0x47,0x0d,0x0a,0x1a,0x0a])))return{mime:'image/png',img:1};
 if(h.subarray(0,4).toString()==='RIFF'&&h.subarray(8,12).toString()==='WEBP')return{mime:'image/webp',img:1};if(h.subarray(0,3).toString()==='GIF')return{mime:'image/gif',img:1};
 if(h.subarray(0,4).toString()==='%PDF')return{mime:'application/pdf'};return null}
const hits=new Map();
function limited(key,max,winMs){const now=Date.now(),a=(hits.get(key)||[]).filter(t=>now-t<winMs);a.push(now);hits.set(key,a);return a.length>max}
setInterval(()=>{const n=Date.now();for(const[k,v]of hits)if(!v.some(t=>n-t<9e5))hits.delete(k)},6e4).unref();
const str=(v,max=200,min=0)=>{v=String(v??'').trim();if(v.length<min)bad('Please fill in all required fields');return v.slice(0,max)};
const int=(v,min,max,d)=>{const n=Math.floor(Number(v));if(!Number.isFinite(n)||n<min||n>max){if(d!==undefined)return d;bad('Invalid number')}return n};
const cents=v=>{const n=Math.round(Number(v)*100);if(!Number.isFinite(n)||n<=0||n>1e10)bad('Enter a valid price');return n};
const EMAIL=/^[^\s@]{1,64}@[^\s@]{1,190}\.[^\s@]{2,}$/;
const email=v=>{v=str(v,254).toLowerCase();if(!EMAIL.test(v))bad('Enter a valid email address');return v};
const pw=v=>{v=String(v||'');if(v.length<8||v.length>200)bad('Password must be at least 8 characters');return v};
module.exports={HttpError,bad,sha,rid,cookies,readBody,multipart,sniff,limited,str,int,cents,email,pw};
