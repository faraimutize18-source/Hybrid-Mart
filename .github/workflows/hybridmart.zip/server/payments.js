'use strict';
/* Payment adapters. Every provider here is configured with the OWNER's own merchant keys, so every payment —
   whichever method the customer picks — settles into the owner's account(s). The platform then pays sellers out of
   its own balance (see payouts). Secrets are stored encrypted and never sent to a browser. */
const crypto=require('crypto');
const {HttpError}=require('./lib');
const J=async(url,o={})=>{const r=await fetch(url,{...o,signal:AbortSignal.timeout(15000)});const t=await r.text();let j;try{j=JSON.parse(t)}catch{j=t}
 if(!r.ok)throw new HttpError(502,`${new URL(url).host} said ${r.status}: ${typeof j==='string'?j.slice(0,160):(j.error?.message||j.message||j.detail||JSON.stringify(j)).toString().slice(0,200)}`);return j};
const major=c=>(c/100).toFixed(2);
const eq=(a,b)=>{a=Buffer.from(String(a));b=Buffer.from(String(b));return a.length===b.length&&crypto.timingSafeEqual(a,b)};

const PROVIDERS={
 stripe:{name:'Stripe',blurb:'Visa, Mastercard, Amex, Apple Pay, Google Pay',icon:'💳',webhook:true,fields:[{k:'secret_key',l:'Secret key (sk_live_… or sk_test_…)',secret:1},{k:'webhook_secret',l:'Webhook signing secret (whsec_…)',secret:1}]},
 paypal:{name:'PayPal',blurb:'PayPal balance and cards',icon:'🅿️',fields:[{k:'client_id',l:'Client ID'},{k:'secret',l:'Client secret',secret:1},{k:'mode',l:'Mode: live or sandbox',ph:'live',opt:1}]},
 flutterwave:{name:'Flutterwave',blurb:'Cards, mobile money (M-Pesa, MTN, Airtel), bank transfer across Africa',icon:'🌍',webhook:true,fields:[{k:'secret_key',l:'Secret key (FLWSECK-…)',secret:1},{k:'webhook_hash',l:'Webhook secret hash (you choose it, same value in Flutterwave dashboard)',secret:1},{k:'options',l:'Payment options (optional, e.g. card,mobilemoneyghana,ussd)',opt:1}]},
 paynow:{name:'Paynow (Zimbabwe)',blurb:'EcoCash, OneMoney, InnBucks, ZimSwitch, Visa/Mastercard',icon:'🇿🇼',webhook:true,fields:[{k:'integration_id',l:'Integration ID'},{k:'integration_key',l:'Integration key',secret:1}]},
 manual:{name:'Manual transfer',blurb:'Bank transfer or send-money to your wallet — you confirm receipt',icon:'🏦',fields:[{k:'instructions',l:'Instructions shown to the customer (account/wallet number, name, how to reference)',area:1}]},
 sandbox:{name:'Test sandbox',blurb:'Fake checkout page for testing — no money moves',icon:'🧪',fields:[]}
};
const A={};
/* ---------- Stripe ---------- */
A.stripe={
 async create(x){const b=new URLSearchParams({mode:'payment',success_url:x.ret,cancel_url:x.ret+'?cancel=1',client_reference_id:x.pay.id,'metadata[payment_id]':x.pay.id,'line_items[0][quantity]':'1','line_items[0][price_data][currency]':x.pay.currency.toLowerCase(),'line_items[0][price_data][unit_amount]':String(x.pay.amount),'line_items[0][price_data][product_data][name]':`${x.site} order ${x.pay.id}`});if(x.user.email)b.set('customer_email',x.user.email);
  const s=await J('https://api.stripe.com/v1/checkout/sessions',{method:'POST',headers:{Authorization:'Bearer '+x.c.secret_key,'Content-Type':'application/x-www-form-urlencoded'},body:b});return{ref:s.id,redirect:s.url}},
 async verify(x){const s=await J('https://api.stripe.com/v1/checkout/sessions/'+encodeURIComponent(x.pay.provider_ref),{headers:{Authorization:'Bearer '+x.c.secret_key}});
  if(s.payment_status==='paid'&&s.amount_total===x.pay.amount&&String(s.currency).toUpperCase()===x.pay.currency)return'paid';return s.status==='expired'?'failed':'pending'},
 webhook(x){const h=x.req.headers['stripe-signature']||'',t=/t=(\d+)/.exec(h)?.[1];if(!t||Math.abs(Date.now()/1e3-t)>600)return null;
  const want=crypto.createHmac('sha256',x.c.webhook_secret||'x').update(t+'.'+x.raw).digest('hex');if(!h.split(',').some(p=>p.startsWith('v1=')&&eq(p.slice(3),want)))return null;
  const ev=JSON.parse(x.raw);return['checkout.session.completed','checkout.session.async_payment_succeeded'].includes(ev.type)?ev.data.object.metadata?.payment_id||ev.data.object.client_reference_id:''}
};
/* ---------- PayPal ---------- */
const ppBase=c=>c.mode==='sandbox'?'https://api-m.sandbox.paypal.com':'https://api-m.paypal.com';
const ppTok=async c=>(await J(ppBase(c)+'/v1/oauth2/token',{method:'POST',headers:{Authorization:'Basic '+Buffer.from(c.client_id+':'+c.secret).toString('base64'),'Content-Type':'application/x-www-form-urlencoded'},body:'grant_type=client_credentials'})).access_token;
A.paypal={
 async create(x){const t=await ppTok(x.c);const o=await J(ppBase(x.c)+'/v2/checkout/orders',{method:'POST',headers:{Authorization:'Bearer '+t,'Content-Type':'application/json','PayPal-Request-Id':x.pay.id},body:JSON.stringify({intent:'CAPTURE',purchase_units:[{reference_id:x.pay.id,custom_id:x.pay.id,amount:{currency_code:x.pay.currency,value:major(x.pay.amount)}}],payment_source:{paypal:{experience_context:{return_url:x.ret,cancel_url:x.ret+'?cancel=1',user_action:'PAY_NOW',brand_name:x.site}}}})});
  const l=(o.links||[]).find(l=>l.rel==='payer-action'||l.rel==='approve');if(!l)throw new HttpError(502,'PayPal returned no approval link');return{ref:o.id,redirect:l.href}},
 async verify(x){const t=await ppTok(x.c),H={Authorization:'Bearer '+t,'Content-Type':'application/json'};let o=await J(ppBase(x.c)+'/v2/checkout/orders/'+x.pay.provider_ref,{headers:H});
  if(o.status==='APPROVED')o=await J(ppBase(x.c)+'/v2/checkout/orders/'+x.pay.provider_ref+'/capture',{method:'POST',headers:{...H,'PayPal-Request-Id':x.pay.id+'-cap'},body:'{}'});
  const cap=o.purchase_units?.[0]?.payments?.captures?.[0];if(o.status==='COMPLETED'&&cap?.status==='COMPLETED'&&cap.amount.value===major(x.pay.amount)&&cap.amount.currency_code===x.pay.currency)return'paid';return'pending'}
};
/* ---------- Flutterwave ---------- */
A.flutterwave={
 async create(x){const body={tx_ref:x.pay.id,amount:Number(major(x.pay.amount)),currency:x.pay.currency,redirect_url:x.ret,customer:{email:x.user.email,name:x.user.name},customizations:{title:x.site}};if(x.c.options)body.payment_options=x.c.options;
  const r=await J('https://api.flutterwave.com/v3/payments',{method:'POST',headers:{Authorization:'Bearer '+x.c.secret_key,'Content-Type':'application/json'},body:JSON.stringify(body)});return{ref:x.pay.id,redirect:r.data.link}},
 async verify(x){const id=x.q?.transaction_id,H={Authorization:'Bearer '+x.c.secret_key};
  const r=await J(id?`https://api.flutterwave.com/v3/transactions/${encodeURIComponent(id)}/verify`:'https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref='+encodeURIComponent(x.pay.id),{headers:H}),d=r.data||{};
  if(d.tx_ref===x.pay.id&&d.status==='successful'&&Number(d.amount)>=Number(major(x.pay.amount))&&d.currency===x.pay.currency)return'paid';return(x.q?.status==='cancelled'||d.status==='failed')?'failed':'pending'},
 webhook(x){if(!eq(x.req.headers['verif-hash']||'',x.c.webhook_hash||'\0'))return null;const ev=JSON.parse(x.raw);return ev.data?.tx_ref||''}
};
/* ---------- Paynow (Zimbabwe) ---------- */
const pnHash=(vals,key)=>crypto.createHash('sha512').update(vals.join('')+key).digest('hex').toUpperCase();
const pnParse=(t,key)=>{const o=Object.fromEntries(new URLSearchParams(t));const{hash,...rest}=o;if(!hash||!eq(hash.toUpperCase(),pnHash(Object.values(rest),key)))throw new HttpError(502,'Paynow response failed signature check: '+(o.error||''));return o};
A.paynow={
 async create(x){const f={id:x.c.integration_id,reference:x.pay.id,amount:major(x.pay.amount),additionalinfo:`${x.site} order`,returnurl:x.ret,resulturl:x.hook,authemail:x.user.email,status:'Message'};
  const t=await J('https://www.paynow.co.zw/interface/initiatetransaction',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams({...f,hash:pnHash(Object.values(f),x.c.integration_key)})});
  const o=pnParse(t,x.c.integration_key);if(String(o.status).toLowerCase()!=='ok')throw new HttpError(502,'Paynow: '+(o.error||o.status));return{ref:o.pollurl,redirect:o.browserurl}},
 async verify(x){const t=await J(x.pay.provider_ref,{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:''});const o=pnParse(t,x.c.integration_key),s=String(o.status).toLowerCase();
  if((s==='paid'||s==='delivered')&&Number(o.amount)>=Number(major(x.pay.amount)))return'paid';return['cancelled','failed','disputed','refunded'].includes(s)?'failed':'pending'},
 webhook(x){const o=Object.fromEntries(new URLSearchParams(x.raw));return o.reference||''}   /* never trusted directly: caller re-verifies via signed poll */
};
/* ---------- Manual & sandbox ---------- */
A.manual={async create(x){return{ref:x.pay.id,manual:x.c.instructions||'Please contact the store for payment details.'}}};
A.sandbox={async create(x){return{ref:x.pay.id,redirect:x.base+'/pay/sandbox/'+x.pay.id}}};

/* Public summary of a method, safe for browsers */
const pub=m=>({id:m.id,provider:m.provider,label:m.label,icon:PROVIDERS[m.provider]?.icon||'💳',blurb:PROVIDERS[m.provider]?.blurb||'',manual:m.provider==='manual',sandbox:m.provider==='sandbox'});
module.exports={PROVIDERS,A,pub,major};
