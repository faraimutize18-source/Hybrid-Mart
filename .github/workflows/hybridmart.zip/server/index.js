'use strict';
require('./env');
const http=require('http'),fs=require('fs'),path=require('path');
const {HttpError,readBody,limited}=require('./lib');
const {q,cfg}=require('./db');
const R=require('./routes'),S=require('./shop');
const PUB=path.join(__dirname,'..','public'),PORT=+process.env.PORT||3000,PROD=process.env.NODE_ENV==='production';
const OWNER_PATH='/'+(process.env.OWNER_PATH||'owner-console').replace(/^\/+/,'');
const MIME={'.html':'text/html;charset=utf-8','.js':'text/javascript;charset=utf-8','.css':'text/css;charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.ico':'image/x-icon','.json':'application/json','.txt':'text/plain'};
const PAGES={'/':'index.html','/sell':'sell.html',[OWNER_PATH]:'owner.html'};
const SEC={'X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY','Referrer-Policy':'strict-origin-when-cross-origin','Permissions-Policy':'camera=(),microphone=(),geolocation=()',
 'Content-Security-Policy':"default-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; form-action 'self'; frame-ancestors 'none'; base-uri 'none'",...(PROD?{'Strict-Transport-Security':'max-age=31536000'}:{})};
const json=(res,code,o)=>{const b=JSON.stringify(o);res.writeHead(code,{'Content-Type':'application/json;charset=utf-8','Cache-Control':'no-store'});res.end(b)};
const server=http.createServer(async(req,res)=>{
 for(const k in SEC)res.setHeader(k,SEC[k]);
 const origWrite=res.writeHead;res.writeHead=function(...a){if(res._ck)res.setHeader('Set-Cookie',res._ck);return origWrite.apply(this,a)};
 try{
  const fwd=process.env.TRUST_PROXY==='1',ip=(fwd&&req.headers['x-forwarded-for']?.split(',')[0].trim())||req.socket.remoteAddress||'?';
  const proto=fwd&&req.headers['x-forwarded-proto']||'http',host=req.headers.host||'localhost';
  const url=new URL(req.url,'http://x'),p=url.pathname;
  const ctx={req,res,url,ip,query:Object.fromEntries(url.searchParams),body:{},raw:'',buf:null,secure:proto==='https'||PROD,base:(process.env.BASE_URL||`${proto}://${host}`).replace(/\/$/,'')};
  if(limited('rate:'+ip,600,6e4))return json(res,429,{error:'Slow down a little'});
  const api=p.startsWith('/api/'),hook=p.startsWith('/api/webhooks/'),pay=p.startsWith('/pay/');
  if(req.method==='GET'||req.method==='HEAD'){
   if(!api&&!pay&&!p.startsWith('/files/')){
    const page=PAGES[p];let fp;if(page)fp=path.join(PUB,page);else if(p.startsWith('/assets/'))fp=path.join(PUB,path.normalize(p).replace(/^(\.\.[\/\\])+/,''));
    if(!fp||!fp.startsWith(PUB)||!fs.existsSync(fp)||!fs.statSync(fp).isFile()){res.writeHead(404,{'Content-Type':'text/plain'});return res.end('Not found')}
    const h={'Content-Type':MIME[path.extname(fp)]||'application/octet-stream','Cache-Control':page?'no-cache':'public,max-age=300'};if(page==='owner.html')Object.assign(h,{'X-Robots-Tag':'noindex,nofollow','Cache-Control':'no-store'});
    res.writeHead(200,h);return fs.createReadStream(fp).pipe(res)}
  }else{
   if(api&&!hook&&req.headers['x-hm']!=='1')throw new HttpError(403,'Blocked request');          // CSRF: browsers cannot send this header cross-site
   const ct=req.headers['content-type']||'';
   if(p==='/api/upload')ctx.buf=await readBody(req,(+process.env.MAX_UPLOAD_MB||100)*1e6+1e6);
   else if(hook)ctx.raw=(await readBody(req,1e6)).toString('utf8');
   else if(pay)await readBody(req,1e5);
   else{const b=await readBody(req,1e6);if(b.length){if(!ct.includes('json'))throw new HttpError(415,'JSON expected');try{ctx.body=JSON.parse(b.toString('utf8'))}catch{throw new HttpError(400,'Malformed JSON')}}}
  }
  const r=await R.route(ctx);if(r===R.RAW)return;
  if(r===undefined)return json(res,404,{error:'Not found'});
  json(res,200,r);
 }catch(e){if(res.headersSent)return res.end();const s=e.status||500;if(s>=500&&!e.status)console.error(e);json(res,s,{error:e.status?e.message:'Something went wrong on our side. Please try again.'})}});
server.listen(PORT,()=>{const c=cfg();console.log(`\n  ${c.siteName} is running → http://localhost:${PORT}\n  Seller centre      → /sell\n  Owner console      → ${OWNER_PATH}`);
 if(!R.ownerExists())console.log(`\n  ┌ FIRST-TIME SETUP ───────────────────────────────┐\n  │ Open ${OWNER_PATH} and create the owner account.\n  │ Setup key (one-time): ${R.setupKey()}\n  └──────────────────────────────────────────────────┘`);
 if(!process.env.BASE_URL)console.log('\n  ⚠ BASE_URL is not set. Set it to your public https address before taking real payments.');
 if(q.get('SELECT 1 x FROM users WHERE demo=1'))console.log('  ⚠ Demo accounts exist (password demo1234). Remove them in Owner → Settings before launch.')});
(async()=>{if(process.env.SEED_DEMO==='1'&&!R.ownerExists()&&await S.seedDemo())console.log('  Demo data loaded');})();
setInterval(S.sweep,5*6e4).unref();setTimeout(S.sweep,5000).unref();
process.on('SIGTERM',()=>server.close(()=>process.exit(0)));
