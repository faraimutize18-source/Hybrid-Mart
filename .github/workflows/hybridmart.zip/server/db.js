'use strict';
require('./env');
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const {DatabaseSync}=require('node:sqlite');
const DATA=process.env.DATA_DIR||path.join(__dirname,'..','data');
fs.mkdirSync(path.join(DATA,'uploads'),{recursive:true});
const db=new DatabaseSync(path.join(DATA,process.env.DB_FILE||'hybridmart.db'));
db.exec('PRAGMA journal_mode=WAL;PRAGMA foreign_keys=ON;PRAGMA busy_timeout=5000;');
const NOW="strftime('%Y-%m-%dT%H:%M:%fZ','now')";
db.exec(`
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,role TEXT NOT NULL,email TEXT NOT NULL,name TEXT NOT NULL,phone TEXT DEFAULT '',salt TEXT NOT NULL,hash TEXT NOT NULL,status TEXT DEFAULT 'active',demo INTEGER DEFAULT 0,created_at TEXT DEFAULT(${NOW}),UNIQUE(email,role));
CREATE TABLE IF NOT EXISTS sessions(th TEXT PRIMARY KEY,user_id INTEGER NOT NULL,role TEXT NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS files(id TEXT PRIMARY KEY,user_id INTEGER,kind TEXT,name TEXT,mime TEXT,size INTEGER,created_at TEXT DEFAULT(${NOW}));
CREATE TABLE IF NOT EXISTS sellers(id INTEGER PRIMARY KEY,user_id INTEGER UNIQUE NOT NULL,business TEXT,country TEXT,address TEXT,reg_no TEXT,tax_id TEXT,about TEXT DEFAULT '',status TEXT DEFAULT 'pending',note TEXT DEFAULT '',logo TEXT,payout_method TEXT DEFAULT '',payout_details TEXT DEFAULT '',demo INTEGER DEFAULT 0,created_at TEXT DEFAULT(${NOW}));
CREATE TABLE IF NOT EXISTS seller_docs(id INTEGER PRIMARY KEY,seller_id INTEGER NOT NULL,file_id TEXT NOT NULL,label TEXT);
CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY,seller_id INTEGER NOT NULL,title TEXT,category TEXT,sub TEXT,type TEXT,order_type TEXT,price INTEGER,moq INTEGER DEFAULT 1,tiers TEXT DEFAULT '[]',stock INTEGER,description TEXT DEFAULT '',bullets TEXT DEFAULT '[]',specs TEXT DEFAULT '[]',ship_fee INTEGER DEFAULT 0,delivery TEXT DEFAULT '',status TEXT DEFAULT 'active',images TEXT DEFAULT '[]',digital_file TEXT,emoji TEXT,hue INTEGER DEFAULT 210,rating REAL DEFAULT 0,review_count INTEGER DEFAULT 0,sold INTEGER DEFAULT 0,demo INTEGER DEFAULT 0,created_at TEXT DEFAULT(${NOW}),updated_at TEXT DEFAULT(${NOW}));
CREATE TABLE IF NOT EXISTS payment_methods(id INTEGER PRIMARY KEY,provider TEXT NOT NULL,label TEXT NOT NULL,enabled INTEGER DEFAULT 1,sort INTEGER DEFAULT 0,cfg TEXT,created_at TEXT DEFAULT(${NOW}));
CREATE TABLE IF NOT EXISTS payments(id TEXT PRIMARY KEY,customer_id INTEGER,method_id INTEGER,provider TEXT,label TEXT,amount INTEGER,currency TEXT,status TEXT,provider_ref TEXT,reference TEXT,note TEXT,proof TEXT,expires INTEGER,created_at TEXT DEFAULT(${NOW}),paid_at TEXT);
CREATE TABLE IF NOT EXISTS orders(id INTEGER PRIMARY KEY,payment_id TEXT,customer_id INTEGER,seller_id INTEGER,status TEXT,subtotal INTEGER,shipping INTEGER,tax INTEGER,fee INTEGER,total INTEGER,seller_net INTEGER,address TEXT,tracking TEXT DEFAULT '',carrier TEXT DEFAULT '',demo INTEGER DEFAULT 0,created_at TEXT DEFAULT(${NOW}),shipped_at TEXT,completed_at TEXT);
CREATE TABLE IF NOT EXISTS order_items(id INTEGER PRIMARY KEY,order_id INTEGER NOT NULL,product_id INTEGER,title TEXT,type TEXT,qty INTEGER,unit INTEGER,total INTEGER,image TEXT);
CREATE TABLE IF NOT EXISTS payouts(id INTEGER PRIMARY KEY,seller_id INTEGER,amount INTEGER,method TEXT,reference TEXT,note TEXT,created_at TEXT DEFAULT(${NOW}));
CREATE TABLE IF NOT EXISTS reviews(id INTEGER PRIMARY KEY,product_id INTEGER,customer_id INTEGER,name TEXT,rating INTEGER,title TEXT,body TEXT,created_at TEXT DEFAULT(${NOW}),UNIQUE(product_id,customer_id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,at TEXT DEFAULT(${NOW}),actor TEXT,action TEXT,detail TEXT);
CREATE INDEX IF NOT EXISTS ix_p ON products(status,category);CREATE INDEX IF NOT EXISTS ix_o1 ON orders(customer_id);CREATE INDEX IF NOT EXISTS ix_o2 ON orders(seller_id);CREATE INDEX IF NOT EXISTS ix_oi ON order_items(order_id);
`);
const cache=new Map(),prep=s=>{let p=cache.get(s);if(!p){p=db.prepare(s);cache.set(s,p)}return p};
const q={get:(s,...a)=>prep(s).get(...a),all:(s,...a)=>prep(s).all(...a),run:(s,...a)=>prep(s).run(...a)};
function tx(fn){db.exec('BEGIN IMMEDIATE');try{const r=fn();db.exec('COMMIT');return r}catch(e){try{db.exec('ROLLBACK')}catch(_){}throw e}}
/* ---- secrets (payment keys are encrypted at rest) ---- */
let SECRET=process.env.APP_SECRET;const sf=path.join(DATA,'.secret');
if(!SECRET){try{SECRET=fs.readFileSync(sf,'utf8')}catch{SECRET=crypto.randomBytes(32).toString('hex');fs.writeFileSync(sf,SECRET,{mode:0o600})}}
const KEY=crypto.scryptSync(SECRET,'hm-enc',32);
const enc=o=>{const iv=crypto.randomBytes(12),c=crypto.createCipheriv('aes-256-gcm',KEY,iv),ct=Buffer.concat([c.update(JSON.stringify(o),'utf8'),c.final()]);return Buffer.concat([iv,c.getAuthTag(),ct]).toString('base64')};
const dec=s=>{try{const b=Buffer.from(s,'base64'),d=crypto.createDecipheriv('aes-256-gcm',KEY,b.subarray(0,12));d.setAuthTag(b.subarray(12,28));return JSON.parse(Buffer.concat([d.update(b.subarray(28)),d.final()]).toString('utf8'))}catch{return{}}};
/* ---- passwords ---- */
const scrypt=(pw,salt)=>new Promise((ok,no)=>crypto.scrypt(pw,salt,64,{N:16384},(e,k)=>e?no(e):ok(k.toString('hex'))));
async function mkpw(pw){const salt=crypto.randomBytes(16).toString('hex');return{salt,hash:await scrypt(pw,salt)}}
async function chkpw(u,pw){if(!u)return false;const h=Buffer.from(await scrypt(pw,u.salt),'hex'),x=Buffer.from(u.hash,'hex');return h.length===x.length&&crypto.timingSafeEqual(h,x)}
/* ---- settings ---- */
const DEF={siteName:'HybridMart',currency:'USD',commission:10,taxOn:false,taxRate:8,holdHours:48,autoCompleteDays:14,supportEmail:'',tagline:'Shop retail. Buy wholesale. Download instantly.'};
function cfg(){const o={...DEF};for(const r of q.all('SELECT key,value FROM settings')){try{o[r.key]=JSON.parse(r.value)}catch{}}return o}
const setCfg=(k,v)=>q.run('INSERT INTO settings(key,value)VALUES(?,?)ON CONFLICT(key)DO UPDATE SET value=excluded.value',k,JSON.stringify(v));
const audit=(actor,action,detail='')=>q.run('INSERT INTO audit(actor,action,detail)VALUES(?,?,?)',String(actor),action,String(detail).slice(0,500));
const CATS={'Electronics':['Audio','Phones & Tablets','Computers','Accessories','Cameras'],'Home & Kitchen':['Kitchen','Drinkware','Decor','Furniture','Storage'],'Apparel & Bags':['Bags','Clothing','Shoes','Jewellery'],'Office & Packaging':['Office','Packaging','Stationery','Industrial'],'Digital Products':['Design','Education','Stock Media','Software','Music & Audio'],'Health & Beauty':['Skincare','Hair care','Wellness'],'Food & Grocery':['Pantry','Beverages','Fresh produce'],'Toys & Hobbies':['Toys','Games','Crafts']};
const SYM={USD:'$',EUR:'€',GBP:'£',ZAR:'R',ZWG:'ZiG',KES:'KSh',NGN:'₦',GHS:'GH₵',BWP:'P'};
module.exports={db,q,tx,DATA,enc,dec,mkpw,chkpw,cfg,setCfg,audit,CATS,SYM,DEF};
