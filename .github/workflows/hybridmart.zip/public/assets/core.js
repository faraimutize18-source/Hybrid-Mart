'use strict';
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let CONF={cats:{},methods:[],symbol:'$',site:'Store'};
async function api(path,{method='GET',body,form}={}){const o={method,headers:{'X-HM':'1'},credentials:'same-origin'};if(body!==undefined){o.headers['Content-Type']='application/json';o.body=JSON.stringify(body)}if(form)o.body=form;
 let r;try{r=await fetch(path,o)}catch{throw new Error('Can’t reach the server — check your connection and try again.')}const j=await r.json().catch(()=>({}));if(!r.ok){const e=new Error(j.error||'Something went wrong');e.status=r.status;throw e}return j}
const fmt=c=>{const s=CONF.symbol||'$';return(s.length>1?s+' ':s)+(c/100).toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2})};
const priceH=c=>{const[w,f]=(c/100).toFixed(2).split('.'),s=(CONF.symbol||'$');return`<span class=price><sup>${esc(s)}</sup>${(+w).toLocaleString()}<sup>${f}</sup></span>`};
const stars=(r,n)=>r?`<span class=sm><span class=stars style="--r:${r}"></span> <span style="color:var(--link)">${(+n||0).toLocaleString()}</span></span>`:'<span class="sm mut">No reviews yet</span>';
const dt=s=>s?new Date(s).toLocaleDateString(undefined,{day:'numeric',month:'short',year:'numeric'}):'—',dtt=s=>s?new Date(s).toLocaleString(undefined,{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit'}):'—';
const CH={Processing:'warn',Shipped:'pri',Delivered:'ok',Completed:'ok','Awaiting payment':'warn',Cancelled:'bad',Refunded:'bad',paid:'ok',pending:'warn',awaiting_confirmation:'warn',failed:'bad',cancelled:'bad',approved:'ok',rejected:'bad',suspended:'bad',active:'ok',flagged:'bad',draft:'',blocked:'bad'};
const chip=s=>`<span class="chip ${CH[s]??''}">${esc(String(s).replace(/_/g,' '))}</span>`;
const art=p=>p.images?.[0]?`<div class=art><img loading=lazy src="${esc(p.images[0])}" alt="${esc(p.title)}"></div>`:`<div class=art style="background:linear-gradient(135deg,hsl(${p.hue|0} 80% 90%),hsl(${((p.hue|0)+40)%360} 75% 78%))">${esc(p.emoji||'📦')}</div>`;
const empty=(em,t,s='')=>`<div class=empty><span class=em>${em}</span><b>${t}</b>${s}</div>`;
const opts=(list,cur)=>list.map(x=>{const[v,t]=Array.isArray(x)?x:[x,x];return`<option value="${esc(v)}" ${String(cur)===String(v)?'selected':''}>${esc(t)}</option>`}).join('');
const COUNTRIES=['Zimbabwe','South Africa','Zambia','Botswana','Mozambique','Namibia','Malawi','Kenya','Nigeria','Ghana','Tanzania','Uganda','Egypt','United Kingdom','United States','Canada','Germany','France','India','China','UAE','Australia','Other'];
/* ---- events: data-act (click), data-form (submit), data-live (input) ---- */
const A={},F={},L={};
document.addEventListener('click',e=>{const t=e.target.closest('[data-act]');if(!t||!A[t.dataset.act])return;if(t.tagName==='A'&&(t.getAttribute('href')||'#')==='#')e.preventDefault();Promise.resolve(A[t.dataset.act](t,e)).catch(x=>toast(x.message,'err'))});
document.addEventListener('submit',async e=>{const f=e.target.closest('form[data-form]');if(!f)return;e.preventDefault();const b=$('button[type=submit],button:not([type])',f),er=$('.ferr',f);if(er)er.innerHTML='';if(b?.disabled)return;if(b){b.disabled=true;b._t=b.textContent}
 try{await F[f.dataset.form](Object.fromEntries(new FormData(f)),f)}catch(x){if(er){er.innerHTML=`<div class=err>${esc(x.message)}</div>`;er.scrollIntoView({block:'nearest'})}else toast(x.message,'err')}finally{if(b)b.disabled=false}});
document.addEventListener('input',e=>{const t=e.target.closest('[data-live]');if(t&&L[t.dataset.live])L[t.dataset.live](t,e)});
document.addEventListener('change',e=>{const t=e.target.closest('[data-change]');if(t&&L[t.dataset.change])L[t.dataset.change](t,e)});
/* ---- ui helpers ---- */
function toast(m,t=''){const e=document.createElement('div');e.className='toast '+t;e.textContent=m;$('#toasts').append(e);setTimeout(()=>e.remove(),t==='err'?5000:3000)}
function modal(h,wide){$('#modal').innerHTML=`<div class=ov data-act=ovx><div class="box ${wide?'wide':''}" role=dialog aria-modal=true>${h}</div></div>`;$('#modal input,#modal select,#modal textarea')?.focus()}
const closeModal=()=>{$('#modal').innerHTML=''};A.close=closeModal;A.ovx=(t,e)=>{if(e.target===t)closeModal()};document.addEventListener('keydown',e=>{if(e.key==='Escape')closeModal()});
const ask=(msg,ok='Confirm',danger)=>new Promise(r=>{modal(`<h3 class=mb>${esc(msg)}</h3><div class="row" style="justify-content:flex-end"><button class=btn data-act=askno>Cancel</button><button class="btn ${danger?'red':'pri'}" data-act=askyes>${esc(ok)}</button></div>`);A.askyes=()=>{closeModal();r(true)};A.askno=()=>{closeModal();r(false)}});
A.copy=t=>navigator.clipboard.writeText(t.dataset.v).then(()=>toast('Copied','ok'));
/* ---- uploads ---- */
function upload(kind,file,{label,onprog}={}){return new Promise((ok,no)=>{const x=new XMLHttpRequest();x.open('POST','/api/upload?kind='+kind+(label?'&label='+encodeURIComponent(label):''));x.setRequestHeader('X-HM','1');x.upload.onprogress=e=>e.lengthComputable&&onprog&&onprog(e.loaded/e.total);
 x.onload=()=>{let j={};try{j=JSON.parse(x.responseText)}catch{}x.status===200?ok(j):no(new Error(j.error||'Upload failed'))};x.onerror=()=>no(new Error('Upload failed — check your connection'));const f=new FormData();f.append('file',file,file.name||'file');x.send(f)})}
const shrink=(file,max=1400)=>new Promise(r=>{if(!/^image\/(jpeg|png|webp)$/.test(file.type))return r(file);const u=URL.createObjectURL(file),i=new Image();i.onload=()=>{const k=Math.min(1,max/Math.max(i.width,i.height)),c=document.createElement('canvas');c.width=Math.round(i.width*k);c.height=Math.round(i.height*k);const x=c.getContext('2d');x.fillStyle='#fff';x.fillRect(0,0,c.width,c.height);x.drawImage(i,0,0,c.width,c.height);URL.revokeObjectURL(u);c.toBlob(b=>r(b?new File([b],file.name.replace(/\.\w+$/,'')+'.jpg',{type:'image/jpeg'}):file),'image/jpeg',.86)};i.onerror=()=>r(file);i.src=u});
const bytes=n=>n>1e6?(n/1e6).toFixed(1)+' MB':Math.max(1,Math.round(n/1e3))+' KB';
const tick=`<div class=tick><svg viewBox="0 0 48 48"><path d="M10 25l9 9 19-20"/></svg></div>`;
/* ---- router ---- */
const ROUTES=[];let QS=new URLSearchParams(),CUR='/';
const route=(p,fn)=>ROUTES.push([new RegExp('^'+p.replace(/:(\w+)/g,'([^/]+)')+'$'),fn]);
const skel=()=>`<div class=wrap><div class="sk" style="height:34px;width:40%;margin:20px 0"></div><div class=grid>${'<div class=sk style="height:270px"></div>'.repeat(8)}</div></div>`;
async function go(){const h=location.hash.slice(1)||'/',[p,qs]=h.split('?');QS=new URLSearchParams(qs||'');CUR=p;const v=$('#view');
 for(const[re,fn]of ROUTES){const m=re.exec(p);if(!m)continue;const my=++go.n;v.innerHTML=skel();let out;try{out=await fn(...m.slice(1).map(decodeURIComponent))}catch(e){if(e.status===401&&go.auth)return go.auth();out=`<div class=wrap><div class=card style="margin:30px auto;max-width:560px">${empty('😕','Something went wrong',esc(e.message)+'<br><br><a href="#/">Go back home</a>')}</div></div>`}
  if(my!==go.n||out===undefined)return;v.innerHTML=out;scrollTo(0,0);document.title=($('#view [data-title]')?.dataset.title?$('#view [data-title]').dataset.title+' — ':'')+CONF.site;if(go.after)go.after();return}
 v.innerHTML=`<div class=wrap>${empty('🧭','Page not found','<a href="#/">Go home</a>')}</div>`}
go.n=0;addEventListener('hashchange',go);
const nav=h=>{location.hash=h};
