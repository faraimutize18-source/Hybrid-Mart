'use strict';
// End-to-end test: boots the real server on a temp database and walks a whole marketplace journey over HTTP.
const {spawn}=require('child_process'),assert=require('assert'),fs=require('fs'),os=require('os'),path=require('path');
const PORT=3900+Math.floor(Math.random()*90),BASE='http://127.0.0.1:'+PORT,DATA=fs.mkdtempSync(path.join(os.tmpdir(),'hm-'));
const jar={};const NAMES={hm_c:'customer',hm_s:'seller',hm_o:'owner'};
async function call(method,url,body,{form,raw}={}){const h={'X-HM':'1',Cookie:Object.entries(jar).map(([k,v])=>k+'='+v).join('; ')};let b;if(form)b=form;else if(body!==undefined){h['Content-Type']='application/json';b=JSON.stringify(body)}
 const r=await fetch(BASE+url,{method,headers:h,body:b,redirect:'manual'});for(const c of r.headers.getSetCookie?.()||[]){const[kv]=c.split(';'),i=kv.indexOf('=');const v=kv.slice(i+1);v?jar[kv.slice(0,i)]=v:delete jar[kv.slice(0,i)]}
 if(raw)return r;const j=await r.json().catch(()=>({}));return{...j,status:r.status,pstatus:j.status}}
const ok=async(...a)=>{const r=await call(...a);assert.ok(r.status===200,`${a[0]} ${a[1]} → ${r.status} ${r.error||''}`);return r};
const PNG=Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==','base64');
const up=(kind,buf,name)=>{const f=new FormData();f.append('file',new Blob([buf]),name);return ok('POST','/api/upload?kind='+kind,undefined,{form:f})};
const step=n=>console.log('  ✔',n);
(async()=>{
 const srv=spawn(process.execPath,['--disable-warning=ExperimentalWarning','server/index.js'],{env:{...process.env,PORT,DATA_DIR:DATA,SETUP_KEY:'testkey123',BASE_URL:BASE},stdio:'ignore'});
 try{for(let i=0;i<40;i++){try{await fetch(BASE+'/api/config');break}catch{await new Promise(r=>setTimeout(r,150))}}
 console.log('Marketplace journey');
 assert.equal((await call('POST','/api/owner/setup',{key:'wrong',email:'o@x.com',name:'Boss',password:'ownerpass123'})).status,403);step('owner setup rejects wrong key');
 await ok('POST','/api/owner/setup',{key:'testkey123',email:'owner@shop.test',name:'Boss',password:'ownerpass123'});step('owner account created');
 assert.equal((await call('POST','/api/owner/methods',{provider:'stripe',config:{}})).status,400);step('payment method needs its keys');
 const m1=(await ok('POST','/api/owner/methods',{provider:'sandbox',label:'Test pay'})).id,m2=(await ok('POST','/api/owner/methods',{provider:'manual',label:'EcoCash / Bank',config:{instructions:'Send to 0771 000 000'}})).id;
 await ok('POST','/api/owner/methods',{provider:'stripe',label:'Cards',config:{secret_key:'sk_test_REALSECRET99',webhook_secret:'whsec_HOOKSECRET99'}});const meth=await ok('GET','/api/owner/methods');assert.ok(!JSON.stringify(meth).includes('REALSECRET99')&&!JSON.stringify(meth).includes('HOOKSECRET99'));assert.ok(!fs.readFileSync(path.join(DATA,'hybridmart.db')).includes('REALSECRET99'));await ok('PUT','/api/owner/methods/3',{label:'Cards',enabled:false,config:{}});const cfgM=await ok('GET','/api/config');assert.equal(cfgM.methods.length,2);step('owner added methods; secrets encrypted & never returned; disabled ones hidden from customers');
 // seller
 delete jar.hm_o;const sj={...jar};
 await ok('POST','/api/seller/apply',{name:'Sam Seller',email:'sam@seller.test',password:'sellerpass1',business:'Sam Goods',country:'Zimbabwe',address:'1 Main St Harare',reg_no:'REG-1',tax_id:'T-1'});
 await up('doc',Buffer.from('%PDF-1.4 test document bytes'),'registration.pdf');
 assert.equal((await call('POST','/api/upload?kind=image',undefined,{form:(()=>{const f=new FormData();f.append('file',new Blob([Buffer.from('<script>alert(1)</script> not an image')]),'x.png');return f})()})).status,400);step('seller applied, uploaded KYB doc; fake image rejected by content sniffing');
 const im=await up('image',PNG,'p.png'),dg=await up('digital',Buffer.from('SECRET CONTENT of the ebook'),'ebook.txt');
 const base={category:'Home & Kitchen',sub:'Kitchen',price:'10.50',description:'Nice',images:[im.id]};
 const phys=await ok('POST','/api/seller/products',{...base,title:'Test Mug',type:'physical',orderType:'retail',stock:5,shipFee:'2'});
 const dig=await ok('POST','/api/seller/products',{...base,category:'Digital Products',sub:'Education',title:'Test Ebook',type:'digital',orderType:'retail',price:'20',digitalFile:dg.id});
 const bulk=await ok('POST','/api/seller/products',{...base,title:'Bulk Bags',type:'physical',orderType:'bulk',price:'3',moq:10,tiers:[{min:10,price:3},{min:100,price:2}],stock:1000});
 assert.equal((await call('POST','/api/seller/products',{...base,title:'Bad tiers',type:'physical',orderType:'bulk',price:'3',moq:10,tiers:[{min:10,price:3},{min:100,price:4}],stock:9})).status,400);step('seller created 3 products (retail, digital with private file, wholesale tiers); bad tiers rejected');
 assert.equal((await call('GET','/api/products')).total,0);step('unapproved seller is not listed publicly');
 // owner approves
 const sellerJar={...jar};await ok('POST','/api/auth/login',{role:'owner',email:'owner@shop.test',password:'ownerpass123'});
 const sl=await ok('GET','/api/owner/sellers');assert.equal(sl.sellers[0].docs.length,1);await ok('POST',`/api/owner/sellers/${sl.sellers[0].id}/decision`,{status:'approved'});
 assert.equal((await call('GET','/api/products')).total,3);step('owner reviewed documents and approved seller → products live');
 // customer
 await ok('POST','/api/auth/register',{name:'Cathy Customer',email:'cathy@buyer.test',password:'buyerpass1'});
 const qt=await ok('POST','/api/quote',{items:[{id:bulk.id,qty:100},{id:phys.id,qty:2}]});assert.equal(qt.groups[0].lines.find(l=>l.id===bulk.id).unit,200);assert.equal(qt.total,20000+2100+200);
 assert.equal((await call('POST','/api/quote',{items:[{id:bulk.id,qty:5}]})).status,400);assert.equal((await call('POST','/api/quote',{items:[{id:phys.id,qty:6}]})).status,400);step('server-side pricing: tier price applied, MOQ and stock enforced');
 const adr={name:'Cathy',phone:'0771234567',line1:'5 Rd',city:'Harare',country:'Zimbabwe'};
 const co=await ok('POST','/api/checkout',{items:[{id:dig.id,qty:1},{id:phys.id,qty:2}],address:adr,methodId:m1});assert.equal(co.next.type,'redirect');
 assert.equal((await call('GET','/api/products/'+phys.id)).stock,3);step('checkout created payment, stock reserved');
 let pay=await ok('GET','/api/payments/'+co.paymentId);assert.equal(pay.pstatus,'pending');
 assert.equal((await call('GET','/api/download/1')).status,403);
 await call('POST',`/pay/sandbox/${co.paymentId}/pay`,undefined,{raw:1});pay=await ok('GET','/api/payments/'+co.paymentId);assert.equal(pay.pstatus,'paid');step('payment confirmed');
 const ords=(await ok('GET','/api/orders')).orders;assert.equal(ords.length,1);const dOrd=ords[0];assert.equal(dOrd.status,'Processing');dOrd.dl=dOrd.items.find(i=>i.type==='digital');assert.ok(dOrd.dl.download);
 const dl=await call('GET','/api/download/'+dOrd.dl.id,undefined,{raw:1});assert.equal(dl.status,200);assert.equal(await dl.text(),'SECRET CONTENT of the ebook');step('digital download unlocked only after payment');
 // another customer cannot download
 const cj={...jar};for(const k in jar)delete jar[k];await ok('POST','/api/auth/register',{name:'Eve',email:'eve@x.test',password:'evepass123'});assert.equal((await call('GET','/api/download/'+dOrd.dl.id)).status,403);step('other customers cannot access the file');
 for(const k in jar)delete jar[k];Object.assign(jar,cj);
 // manual payment flow
 const co2=await ok('POST','/api/checkout',{items:[{id:bulk.id,qty:10}],address:adr,methodId:m2});assert.equal(co2.next.type,'manual');
 const prf=await up('proof',PNG,'receipt.png').catch(()=>null);
 // proof needs customer role: jar currently has customer
 await ok('POST',`/api/payments/${co2.paymentId}/proof`,{reference:'ECO123456',proofFile:prf?.id});step('manual payment: customer submitted reference + proof');
 // seller ships
 Object.assign(jar,{hm_s:sellerJar.hm_s});const so=await ok('GET','/api/seller/orders');const mug=so.orders.find(o=>o.status==='Processing');assert.ok(mug);assert.ok(mug.address);assert.ok(!so.orders.some(o=>o.total===3000&&o.status==='Awaiting payment'));
 await ok('POST',`/api/seller/orders/${mug.code}/ship`,{tracking:'TRK123',carrier:'DHL'});step('seller shipped paid order with tracking');
 // owner confirms manual payment
 await ok('POST','/api/auth/login',{role:'owner',email:'owner@shop.test',password:'ownerpass123'});const op=await ok('GET','/api/owner/payments');const pending=op.payments.find(p=>p.status==='awaiting_confirmation');assert.equal(pending.reference,'ECO123456');assert.ok(pending.proof);
 await ok('POST',`/api/owner/payments/${pending.id}/confirm`);const d=await ok('GET','/api/owner/dashboard');assert.equal(d.paid,co.total+co2.total);assert.ok(d.fee>0);step(`owner confirmed manual payment; all ${d.paid/100} collected on owner side; commission ${d.fee/100}`);
 // customer receives, reviews
 await ok('POST',`/api/orders/${mug.code}/received`);await ok('POST',`/api/products/${phys.id}/reviews`,{rating:5,title:'Great',body:'Lovely mug'});assert.equal((await call('GET','/api/products/'+phys.id)).rating,5);step('customer confirmed receipt and left verified review');
 // payouts: hold period blocks immediate payout
 await ok('POST','/api/owner/settings'.replace('POST','PUT'),{}).catch(()=>{});
 const set=(await ok('GET','/api/owner/settings')).settings;await ok('PUT','/api/owner/settings',{...set,holdHours:0});const po=await ok('GET','/api/owner/payouts');const bal=po.sellers[0].balance;assert.ok(bal.available>0);
 assert.equal((await call('POST','/api/owner/payouts',{sellerId:po.sellers[0].id,amount:(bal.available/100)+1,method:'EcoCash',reference:'x'})).status,400);await ok('POST','/api/owner/payouts',{sellerId:po.sellers[0].id,amount:bal.available/100,method:'EcoCash',reference:'PAYOUT1'});
 assert.equal((await ok('GET','/api/owner/payouts')).sellers[0].balance.available,0);step('owner paid seller out of the single collected balance; overpayment blocked');
 // unauth + csrf
 for(const k in jar)delete jar[k];assert.equal((await call('GET','/api/owner/dashboard')).status,401);const r=await fetch(BASE+'/api/auth/login',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});assert.equal(r.status,403);step('owner API closed to the public; cross-site POSTs blocked');
 // static pages
 for(const[u,t]of[['/','HybridMart'],['/sell','Seller'],['/owner-console','Owner']]){const x=await fetch(BASE+u);assert.equal(x.status,200)}step('three sites served');
 console.log('\nALL PASSED');}catch(e){console.error('\n✖ FAILED:',e.message);process.exitCode=1}finally{srv.kill();fs.rmSync(DATA,{recursive:true,force:true})}})();
