# HybridMart — multi-vendor marketplace (retail · wholesale · digital downloads)

A complete, deployable marketplace: **customer storefront** (Amazon-style), **seller centre** (Alibaba-style),
and a private **owner console**. Real database, real logins, real file uploads, and an owner-controlled payment layer
where customers can pay with *any* method you enable and **all money settles into your own account(s)**.

Zero npm dependencies. Needs only **Node.js 22.5+** (uses its built-in SQLite).

## Try it in 60 seconds
```bash
npm run demo          # starts on http://localhost:3000 with sample sellers & products
```
* Shop: `http://localhost:3000/`      (demo login `customer@example.com` / `demo1234`)
* Seller centre: `/sell`               (demo login `seller@example.com` / `demo1234`)
* Owner console: `/owner-console`      (create the owner account with the one-time **setup key printed in the terminal**)

In the owner console go to **Payment methods → Add → Test sandbox** and you can run a full fake purchase.
`npm test` runs an automated end-to-end journey (owner → seller → customer → payment → shipping → payout).

## How money flows (your "one account" requirement)
```
 Customer pays ──► ANY method you enabled (card / EcoCash / bank / wallet)
                         │   each method is wired to YOUR merchant account with the provider
                         ▼
              YOUR account(s)  ◄── everything lands here, nothing goes to sellers directly
                         │
        order delivered + protection period (default 48h)
                         ▼
   Seller's share becomes "ready to pay" ──► you pay the seller (Owner → Seller payouts → record payout)
```
Your commission (default 10%) and any tax stay with you. Owner → Overview shows collected / your revenue / owed to sellers.

Prices, fees and totals are always computed on the **server** from the database — a customer can't tamper with them.
Stock is reserved at checkout and automatically returned if payment isn't completed.

## Payment methods (Owner → Payment methods)
| Method | What customers get | You provide |
|---|---|---|
| **Paynow** (Zimbabwe) | EcoCash, OneMoney, InnBucks, ZimSwitch, Visa/Mastercard | Integration ID + key |
| **Flutterwave** | Cards, mobile money (M-Pesa, MTN, Airtel…), bank transfer | Secret key + webhook hash |
| **Stripe** | Cards, Apple/Google Pay | Secret key + webhook secret |
| **PayPal** | PayPal & cards | Client ID + secret |
| **Manual transfer** | Bank / wallet "send money" with your instructions; customer submits reference + proof, **you confirm** | Instructions text |
| **Test sandbox** | Fake checkout for testing (disabled when `NODE_ENV=production`) | nothing |

Add/remove/hide a method any time — no code, no restart. Keys are encrypted at rest (AES-256-GCM) and never sent back to a browser.
Webhook URLs are shown on each method's Edit screen.

> **Important — verify before launch.** The Paynow / Flutterwave / Stripe / PayPal connectors follow each provider's public API,
> but they could not be run against live provider accounts while building this. The sandbox and manual flows are tested
> end-to-end; for each real provider, run one small real/test-mode payment and confirm it reaches *Paid* before opening to the public.
> **Provider eligibility depends on where your business is registered** — e.g. Stripe only onboards businesses registered in its
> supported countries; check each provider's current list. For a Zimbabwe business, Paynow and Flutterwave are the usual starting points.

## What you need to go live ("licensing, web server, website")
1. **Business & provider approval** – a registered business (and bank/wallet account) so payment providers will approve your merchant account. Each provider has its own KYC. Check local rules for operating a marketplace / e-commerce, tax, and data protection in your country(ies).
2. **A server** – any small VPS (1 GB RAM is fine) running Node 22.5+, **or** Docker (`docker build -t hybridmart . && docker run -d -p 3000:3000 -v hm:/data --env-file .env hybridmart`).
3. **A domain + HTTPS** – use the included `deploy/Caddyfile` (automatic certificates). Payment providers require https.
4. **Configure** – `cp .env.example .env`, set `BASE_URL`, `OWNER_PATH`, `TRUST_PROXY=1`. Start: `npm start` (or the systemd unit in `deploy/`).
5. **Create the owner account** at `https://yourdomain.com/<OWNER_PATH>` with the setup key from the server log.
6. **Add payment methods**, set commission/currency in **Settings**, remove demo data, and place a test order.
7. **Back up** the `data/` folder (database, uploads **and `.secret`**) daily. Losing `.secret`/`APP_SECRET` makes saved payment keys unreadable.

## Features
**Customers** – search + department filters, product pages with gallery, wholesale tier-price tables, buy box, reviews (verified buyers only), cart, address, choose payment method, live payment status page, order tracking timeline, instant private downloads for digital goods, confirm receipt.
**Sellers** – apply with business documents, owner approval, product editor with drag-and-drop multi-photo upload, private digital-file upload (progress bar), MOQ + volume pricing, stock, delivery fee, orders & shipping with tracking, earnings, payout details, logo.
**Owner** – overview & 14-day chart, confirm/reject manual payments (with proof), payment-method manager, orders & refunds (recorded), seller approval/suspension with document viewer, product takedown, seller payouts ledger, customer blocking, settings, activity log, one-click demo data removal.

## Security
scrypt password hashing · HttpOnly SameSite cookies, separate sessions per site · CSRF header check · login rate limiting & lockout · owner IP allow-list option · uploads verified by file signature (not file name), size-limited, images re-encoded in the browser, private files only served to their owner/buyer · digital files only downloadable after payment · strict CSP / security headers · parameterised SQL · all user text escaped · payment keys encrypted · every sensitive action in the activity log.

## Layout
```
server/  env.js · db.js (schema, settings, crypto) · lib.js · payments.js (providers) · shop.js (pricing, checkout, payouts) · routes.js (API) · index.js
public/  index.html (shop) · sell.html · owner.html · assets/{app.css, core.js, customer.js, seller.js, owner.js}
test/    smoke.test.js   deploy/  Caddyfile, systemd unit
```

## Known limits / sensible next steps
* No e-mail/SMS notifications yet (orders, approvals) — add an SMTP/WhatsApp hook in `shop.js` (`markPaid`, `ship`).
* Refunds are *recorded*; you return the money from your provider dashboard/wallet.
* One store currency at a time. SQLite on one server handles a lot (thousands of orders/day); move to Postgres + object storage when you outgrow it.
* Owner console has password + rate limiting + optional IP allow-list but no 2-factor yet.
* Uploads are held in memory while received (default cap 100 MB).
